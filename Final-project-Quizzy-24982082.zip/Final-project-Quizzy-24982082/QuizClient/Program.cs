﻿using System;
using System.Net.Sockets;
using System.Text;

class Client
{
    static void Main()
    {
        Console.Write("Server IP address? ");
        string? ip = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(ip))
        {
            Console.WriteLine("Invalid IP address. Closing the program.");
            return;
        }

        try
        {
            TcpClient client = new TcpClient();
            client.Connect(ip, 5000);
            NetworkStream stream = client.GetStream();

            string? welcome = ReadMessage(stream);
            if (welcome == null)
            {
                Console.WriteLine("Error receiving the welcome message.");
                return;
            }
            Console.WriteLine(welcome);

            while (true)
            {
                string? serverMsg = ReadMessage(stream);
                if (serverMsg == null)
                {
                    Console.WriteLine("Connection broken.");
                    break;
                }

                if (serverMsg.StartsWith("Question"))
                {
                    Console.WriteLine(serverMsg);
                    Console.Write("Your answer: ");
                    string? answer = Console.ReadLine();
                    if (string.IsNullOrWhiteSpace(answer))
                    {
                        Console.WriteLine("Empty response, sending an empty response to the server.");
                        answer = "";
                    }
                    SendMessage(stream, answer);
                    string? feedback = ReadMessage(stream);
                    if (feedback == null)
                    {
                        Console.WriteLine("Connection interrupted upon receiving the response.");
                        break;
                    }
                    Console.WriteLine(feedback);
                }
                else if (serverMsg.StartsWith("End of the game"))
                {
                    Console.WriteLine(serverMsg);
                    break;
                }
                else
                {
                    Console.WriteLine(serverMsg);
                }
            }

            stream.Close();
            client.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Network error : {ex.Message}");
        }

        Console.WriteLine("Game over. Press a key to exit.");
        Console.ReadKey();
    }

    static void SendMessage(NetworkStream stream, string message)
    {
        byte[] data = Encoding.UTF8.GetBytes(message + "\n");
        stream.Write(data, 0, data.Length);
    }

    static string? ReadMessage(NetworkStream stream)
    {
        byte[] data = new byte[1024];
        try
        {
            int bytesRead = stream.Read(data, 0, data.Length);
            if (bytesRead == 0)
                return null;
            return Encoding.UTF8.GetString(data, 0, bytesRead).Trim();
        }
        catch
        {
            return null;
        }
    }
}

