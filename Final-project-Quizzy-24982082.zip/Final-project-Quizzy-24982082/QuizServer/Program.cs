﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Linq;
using System.Collections.Generic;

class Server
{
    static TcpListener listener;
    static TcpClient[] clients = new TcpClient[2];
    static NetworkStream[] streams = new NetworkStream[2];
    static int[] scores = new int[2];

    static void Main()
    {
        listener = new TcpListener(IPAddress.Any, 5000);
        listener.Start();
        Console.WriteLine("Server started, waiting for 2 players...");

        for (int i = 0; i < 2; i++)
        {
            clients[i] = listener.AcceptTcpClient();
            streams[i] = clients[i].GetStream();
            SendMessage(streams[i], $"\nYou are the player {i + 1}");
            Console.WriteLine($"Player {i + 1} connected.");
        }

        for (int i = 0; i < 2; i++) scores[i] = 0;
        PlayQuiz();

        for (int i = 0; i < 2; i++)
        {
            SendMessage(streams[i], "End of the game. Thank you for playing!\n");
            streams[i].Close();
            clients[i].Close();
        }
        listener.Stop();
        Console.WriteLine("Game over, server down.");
    }

    static void PlayQuiz()
    {
        var random = new Random();
        var questionsMelangees = new List<(string Question, string Answer)>(Questions.All);
        questionsMelangees = questionsMelangees.OrderBy(q => random.Next()).Take(10).ToList();

        for (int q = 0; q < questionsMelangees.Count; q++)
        {
            string question = questionsMelangees[q].Question;
            string correctAnswer = questionsMelangees[q].Answer.ToLower();
            for (int i = 0; i < 2; i++)
            {
                SendMessage(streams[i], $"Question {q + 1}: {question}");
            }
            string[] answers = new string[2];
            for (int i = 0; i < 2; i++)
            {
                answers[i] = ReceiveMessage(streams[i]).ToLower().Trim();
                Console.WriteLine($"Answer of the player {i + 1}: {answers[i]}");
                if (answers[i] == correctAnswer)
                {
                    scores[i]++;
                    SendMessage(streams[i], "Good answer !");
                }
                else
                {
                    SendMessage(streams[i], $"Wrong answer, the correct one was : {correctAnswer}");
                }
            }
        }
        for (int i = 0; i < 2; i++)
        {
            SendMessage(streams[i], $"End of the quiz! Your score : {scores[i]} / {questionsMelangees.Count}");
        }
        string result;
        if (scores[0] > scores[1])
            result = "Player 1 wins!\n";
        else if (scores[1] > scores[0])
            result = "Player 2 wins!\n";
        else
            result = "Draw !\n";
        for (int i = 0; i < 2; i++)
        {
            SendMessage(streams[i], result);
        }
        Console.WriteLine("Final scores :\n");
        Console.WriteLine($"Player 1 : {scores[0]}\n");
        Console.WriteLine($"Player 2 : {scores[1]}\n");
        Console.WriteLine(result);
    }

    static void SendMessage(NetworkStream stream, string message)
    {
        byte[] data = Encoding.UTF8.GetBytes(message + "\n");
        stream.Write(data, 0, data.Length);
    }

    static string ReceiveMessage(NetworkStream stream)
    {
        byte[] data = new byte[1024];
        int bytesRead = stream.Read(data, 0, data.Length);
        return Encoding.UTF8.GetString(data, 0, bytesRead).Trim();
    }
}