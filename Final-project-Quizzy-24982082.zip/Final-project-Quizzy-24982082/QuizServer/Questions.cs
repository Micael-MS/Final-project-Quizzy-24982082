using System.Collections.Generic;

public static class Questions
{
    public static List<(string Question, string Answer)> All = new List<(string, string)>
    {
        ("What is the capital of France?", "Paris"),
        ("What is 2 + 2?", "4"),
        ("What color do you get when you mix blue and yellow?", "Green"),
        ("What is the largest ocean in the world?", "Pacific"),
        ("In what year did man first walk on the moon?", "1969"),
        ("How many continents are there?", "7"),
        ("Which planet is closest to the sun?", "Mercury"),
        ("What is the fastest land animal?", "Cheetah"),
        ("How many players are there in a football (soccer) team?", "11"),
        ("What language is mainly spoken in Brazil?", "Portuguese"),

        ("What is the chemical symbol for water?", "H2O"),
        ("What is the freezing point of water in Celsius?", "0"),
        ("What is the square root of 81?", "9"),
        ("In which country is the Great Pyramid of Giza located?", "Egypt"),
        ("What is the smallest prime number?", "2"),
        ("What organ pumps blood through the body?", "Heart"),

        ("What year did World War II end?", "1945"),
        ("How many sides does a hexagon have?", "6"),
        ("What is the process by which plants make food?", "Photosynthesis"),
        ("What is the capital city of Japan?", "Tokyo"),
        ("What element has the atomic number 1?", "Hydrogen"),
        ("How many bones are in the adult human body?", "206"),
        ("What is the tallest mountain in the world?", "Everest"),

        ("What is the boiling point of water in Celsius?", "100"),
        ("Which planet is known as the Red Planet?", "Mars"),
        ("How many hours are there in a day?", "24"),
        ("What is the largest desert in the world?", "Sahara"),
        ("Which country is known as the Land of the Rising Sun?", "Japan"),
        ("What is the hardest natural substance on Earth?", "Diamond"),

        ("What is the capital of Australia?", "Canberra"),
        ("Which organ is responsible for filtering blood?", "Kidneys"),
        ("How many planets are in the Solar System?", "8"),
        ("What is the chemical formula for table salt?", "NaCl"),
        ("What is the main ingredient in bread?", "Flour"),
        ("Which ocean is the smallest?", "Arctic"),
        ("What gas do humans need to breathe?", "Oxygen"),
        ("What is the currency of Japan?", "Yen"),
        ("What year did the internet become publicly available?", "1991"),

        ("What is the name of our galaxy?", "Milky Way"),
        ("How many degrees are in a circle?", "360"),
        ("What is the capital of Canada?", "Ottawa"),
        ("What is the largest organ in the human body?", "Skin"),
        ("What country is famous for the Eiffel Tower?", "France"),
        ("How many continents are there on Earth?", "7"),
        ("Which planet has the most moons?", "Saturn"),
        
        ("What is the capital city of Italy?", "Rome"),
        ("Who painted the ceiling of the Sistine Chapel?", "Michelangelo"),
        ("What is the main language spoken in Argentina?", "Spanish"),
        ("How many legs does a spider have?", "8"),
        ("What year did the Titanic sink?", "1912"),
        ("Which element is represented by the symbol 'O'?", "Oxygen"),
        ("What is the currency of Russia?", "Ruble"),
        ("How many planets are in the solar system?", "8"),
        ("What device is used to measure temperature?", "Thermometer"),

        ("What is the name of the longest river in the world?", "Nile"),
        ("What is the powerhouse of the cell?", "Mitochondria"),
        ("Which country gifted the Statue of Liberty to the USA?", "France"),
        ("What year did World War I begin?", "1914"),
        ("How many valves does the human heart have?", "4"),
        ("What is the freezing point of water in Fahrenheit?", "32"),
        ("Which instrument measures atmospheric pressure?", "Barometer"),

        ("Which planet is known for its rings?", "Saturn"),
        ("What is the capital of Germany?", "Berlin"),
        ("What organ in the human body produces insulin?", "Pancreas"),
        ("How many players are on a basketball court for one team?", "5"),
        ("What is the chemical symbol for gold?", "Au"),
        ("Which country is known as the Land of the Midnight Sun?", "Norway"),


        ("What is the main language spoken in Egypt?", "Arabic"),
        ("How many teeth does an adult human typically have?", "32"),
        ("Which planet is the hottest in our solar system?", "Venus"),
        ("What year did the Berlin Wall fall?", "1989"),
        ("What is the main ingredient in guacamole?", "Avocado"),

        ("What is the longest bone in the human body?", "Femur"),
        ("What is the hardest rock?", "Diamond"),
        ("What is the chemical symbol for iron?", "Fe"),
        ("Which continent is the Sahara Desert located on?", "Africa"),
        ("Which planet is famous for its Great Red Spot?", "Jupiter"),
        ("How many strings does a standard guitar have?", "6"),

        ("What is the name of the first artificial satellite?", "Sputnik"),
        ("What is the freezing point of water in Kelvin?", "273.15"),
        ("What is the capital of China?", "Beijing"),
        ("Which element has the atomic number 6?", "Carbon"),
        ("What is the main gas found in Earth's atmosphere?", "Nitrogen"),
        ("What is the term for animals that live both on land and in water?", "Amphibians"),
        ("What is the smallest unit of life?", "Cell"),

        ("What is the capital of Spain?", "Madrid"),
        ("What planet is known as Earth's twin?", "Venus"),
        ("What is the term for a word that has the opposite meaning of another?", "Antonym"),
        ("What is the chemical symbol for sodium?", "Na"),
        ("What is the largest island in the world?", "Greenland"),
        ("What is the term for animals that eat both plants and meat?", "Omnivores"),
        ("What year did the French Revolution begin?", "1789"),
    };
}

