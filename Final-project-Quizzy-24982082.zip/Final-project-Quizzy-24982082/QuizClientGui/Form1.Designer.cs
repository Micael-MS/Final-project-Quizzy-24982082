﻿namespace QuizClientGui
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblQuestionNum;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Panel panelHome;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox txtIp;
        private System.Windows.Forms.Button btnConnect;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblQuestionNum = new System.Windows.Forms.Label();
            this.panelMain = new System.Windows.Forms.Panel();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.panelFooter = new System.Windows.Forms.Panel();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.panelHome = new System.Windows.Forms.Panel();
            this.btnStart = new System.Windows.Forms.Button();
            this.txtIp = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.SuspendLayout();

            
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Height = 70;
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Controls.Add(this.lblScore);
            this.panelHeader.Controls.Add(this.lblQuestionNum);
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.TabIndex = 0;

            
            this.lblTitle.Text = "Quizzy";
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(20, 15);
            this.lblTitle.Size = new System.Drawing.Size(220, 40);

            
            this.lblScore.Text = "Score : 0";
            this.lblScore.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblScore.ForeColor = System.Drawing.Color.FromArgb(46, 204, 113);
            this.lblScore.Location = new System.Drawing.Point(260, 15);
            this.lblScore.Size = new System.Drawing.Size(120, 25);

            
            this.lblQuestionNum.Text = "Question : -";
            this.lblQuestionNum.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblQuestionNum.ForeColor = System.Drawing.Color.FromArgb(241, 196, 15);
            this.lblQuestionNum.Location = new System.Drawing.Point(400, 15);
            this.lblQuestionNum.Size = new System.Drawing.Size(140, 25);

            
            this.panelMain.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelMain.Location = new System.Drawing.Point(0, 70);
            this.panelMain.Size = new System.Drawing.Size(580, 230);
            this.panelMain.Controls.Add(this.lblQuestion);
            this.panelMain.Controls.Add(this.txtLog);
            this.panelMain.Name = "panelMain";
            this.panelMain.TabIndex = 1;

            
            this.lblQuestion.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblQuestion.Location = new System.Drawing.Point(30, 20);
            this.lblQuestion.Size = new System.Drawing.Size(520, 60);
            this.lblQuestion.Text = "";
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.TabIndex = 10;

            
            this.txtLog.Location = new System.Drawing.Point(30, 100);
            this.txtLog.Multiline = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.ReadOnly = true;
            this.txtLog.Size = new System.Drawing.Size(520, 110);
            this.txtLog.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtLog.BackColor = System.Drawing.Color.White;
            this.txtLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            
            this.panelFooter.BackColor = System.Drawing.Color.FromArgb(236, 240, 241);
            this.panelFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelFooter.Height = 70;
            this.panelFooter.Controls.Add(this.txtAnswer);
            this.panelFooter.Controls.Add(this.btnSend);
            this.panelFooter.Location = new System.Drawing.Point(0, 300);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.TabIndex = 2;

            
            this.txtAnswer.Location = new System.Drawing.Point(30, 22);
            this.txtAnswer.Size = new System.Drawing.Size(400, 28);
            this.txtAnswer.Enabled = false;
            this.txtAnswer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            
            this.btnSend.Location = new System.Drawing.Point(450, 20);
            this.btnSend.Size = new System.Drawing.Size(100, 32);
            this.btnSend.Text = "Send";
            this.btnSend.Enabled = false;
            this.btnSend.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnSend.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnSend.ForeColor = System.Drawing.Color.White;
            this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSend.FlatAppearance.BorderSize = 0;
            this.btnSend.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);

            
            this.panelHome.BackColor = System.Drawing.Color.FromArgb(155, 89, 182);
            this.panelHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHome.Controls.Add(this.btnStart);
            this.panelHome.Controls.Add(this.txtIp);
            this.panelHome.Controls.Add(this.btnConnect);
            this.panelHome.Location = new System.Drawing.Point(0, 0);
            this.panelHome.Name = "panelHome";
            this.panelHome.TabIndex = 3;

            
            this.btnStart.Text = "Start the quiz";
            this.btnStart.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(241, 196, 15);
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.FlatAppearance.BorderSize = 0;
            this.btnStart.Size = new System.Drawing.Size(320, 60);
            this.btnStart.Location = new System.Drawing.Point(130, 120);
            this.btnStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);

            
            this.txtIp.Location = new System.Drawing.Point(170, 60);
            this.txtIp.Size = new System.Drawing.Size(160, 28);
            this.txtIp.Text = "127.0.0.1";
            this.txtIp.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtIp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            
            this.btnConnect.Location = new System.Drawing.Point(340, 60);
            this.btnConnect.Size = new System.Drawing.Size(110, 28);
            this.btnConnect.Text = "Sign in";
            this.btnConnect.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnConnect.BackColor = System.Drawing.Color.FromArgb(46, 204, 113);
            this.btnConnect.ForeColor = System.Drawing.Color.White;
            this.btnConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnect.FlatAppearance.BorderSize = 0;
            this.btnConnect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);

            
            this.ClientSize = new System.Drawing.Size(580, 370);
            this.Controls.Add(this.panelHeader);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panelHome);
            this.Name = "Form1";
            this.Text = "Quizzy Client";
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}