using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizClientGui
{
    public partial class Form1 : Form
    {
        TcpClient? client;
        NetworkStream? stream;
        int score = 0;
        int questionNumber = 0;
        bool quizStarted = false;
        bool firstQuestionDisplayed = false;

        public Form1()
        {
            InitializeComponent();
            ShowHome();
        }

        private void ShowHome()
        {
            panelHome.Visible = true;
            panelHeader.Visible = false;
            panelMain.Visible = false;
            panelFooter.Visible = false;
        }

        private void ShowQuiz()
        {
            panelHome.Visible = false;
            panelHeader.Visible = true;
            panelMain.Visible = true;
            panelFooter.Visible = true;
        }

        private async void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                client = new TcpClient();
                await client.ConnectAsync(txtIp.Text.Trim(), 5000);
                stream = client.GetStream();
                btnConnect.Enabled = false;
                btnStart.Enabled = true;
                MessageBox.Show("Connected! Click on 'Start the quiz'.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection error :" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (client != null && client.Connected)
            {
                ShowQuiz();
                quizStarted = true;
                score = 0;
                questionNumber = 0;
                lblScore.Text = "Score : 0";
                lblQuestionNum.Text = "Question : -";
                txtLog.Clear();
                lblQuestion.Text = "";
                txtAnswer.Enabled = true;
                btnSend.Enabled = true;
                firstQuestionDisplayed = false;
                _ = Task.Run(ListenForMessages);
            }
            else
            {
                MessageBox.Show("Please log in first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private async void btnSend_Click(object sender, EventArgs e)
        {
            if (stream != null)
            {
                string message = txtAnswer.Text.Trim();
                await SendMessage(message);
                txtAnswer.Clear();
            }
        }

        private async Task ListenForMessages()
        {
            try
            {
                while (quizStarted)
                {
                    string? serverMsg = await ReadMessage();
                    if (serverMsg == null)
                        break;

                    Invoke(new Action(() =>
                    {
                        if (!firstQuestionDisplayed && serverMsg.StartsWith("Question"))
                        {
                            questionNumber++;
                            lblQuestionNum.Text = $"Question : {questionNumber}";
                            lblQuestion.Text = serverMsg;
                            firstQuestionDisplayed = true;
                        }
                        else
                        {
                            AppendLog(serverMsg);
                            if (serverMsg.StartsWith("Question"))
                            {
                                questionNumber++;
                                lblQuestionNum.Text = $"Question : {questionNumber}";
                                lblQuestion.Text = serverMsg;
                            }
                        }
                        if (serverMsg.Contains("Good answer\n"))
                        {
                            score++;
                            lblScore.Text = $"Score : {score}";
                        }
                        if (serverMsg.StartsWith("End of the quiz\n") || serverMsg.Contains("won\n") || serverMsg.Contains("Draw\n"))
                        {
                            txtAnswer.Enabled = false;
                            btnSend.Enabled = false;
                            quizStarted = false;
                            MessageBox.Show("Quiz ended !", "End", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }));
                }
            }
            catch
            {
                Invoke(new Action(() => AppendLog("Connexion lost.")));
            }
        }

        private void AppendLog(string text)
        {
            if (text.StartsWith("Question"))
            {
                
            }
            else
            {
                txtLog.AppendText(text + Environment.NewLine);
            }
        }

        private async Task SendMessage(string message)
        {
            if (stream != null && stream.CanWrite)
            {
                byte[] data = Encoding.UTF8.GetBytes(message + "\n");
                await stream.WriteAsync(data, 0, data.Length);
            }
        }

        private async Task<string?> ReadMessage()
        {
            if (stream == null) return null;

            byte[] data = new byte[1024];
            int bytesRead = await stream.ReadAsync(data, 0, data.Length);
            if (bytesRead == 0) return null;

            return Encoding.UTF8.GetString(data, 0, bytesRead).TrimEnd('\r', '\n');
        }
    }
}